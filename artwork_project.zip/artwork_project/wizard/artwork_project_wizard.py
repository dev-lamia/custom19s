from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class ArtworkProjectCreateWizard(models.TransientModel):
    _name = 'artwork.project.create.wizard'
    _description = 'Create Artwork Project'

    name = fields.Char(string='Name', required=True)
    sale_order_id = fields.Many2one(
        'sale.order',
        string='Sales Order',
        required=True,
        readonly=True,
    )
    project_template_id = fields.Many2one(
        'project.project',
        string='Project Template',
        domain="[('id', 'in', available_template_ids)]",
        help='Select a project template to copy its project configuration and stages.',
    )
    available_template_ids = fields.Many2many(
        'project.project',
        compute='_compute_available_template_ids',
    )

    @api.depends_context('uid', 'allowed_company_ids')
    def _compute_available_template_ids(self):
        Project = self.env['project.project']
        domain = []
        # Odoo editions/customizations that expose the standard template flag
        # are filtered to templates only. Fallback keeps compatibility where
        # that flag is not installed.
        if 'is_template' in Project._fields:
            domain.append(('is_template', '=', True))
        if 'active' in Project._fields:
            domain.append(('active', '=', True))
        templates = Project.search(domain)
        for wizard in self:
            wizard.available_template_ids = templates

    def action_create_project(self):
        self.ensure_one()
        order = self.sale_order_id

        if order.state != 'sale':
            raise ValidationError(
                _('Artwork can only be created after the Sales Order is confirmed.')
            )
        if order.artwork_task_ids:
            raise ValidationError(
                _('Artwork has already been created for this Sales Order.')
            )

        job_lines = order.order_line.filtered(
            lambda line: not line.display_type and line.job_code
        )
        if not job_lines:
            raise ValidationError(
                _('No Sales Order line with a Job Code was found.')
            )

        project_vals = {
            'name': self.name,
            'partner_id': order.partner_id.id,
            'company_id': order.company_id.id,
        }
        if self.project_template_id:
            # Use Odoo 19's native "create from template" copy context.
            # project.project.copy() then copies template tasks/subtasks, stages,
            # milestones, dependencies and settings exactly like the standard UI.
            # account_id is copy=False in Odoo, so the new non-template project
            # gets its own analytic account through the standard timesheet logic.
            project = self.project_template_id.with_context(
                copy_from_template=True,
            ).copy(default=project_vals)
        else:
            project = self.env['project.project'].create(project_vals)

        task_values = []
        for line in job_lines:
            task_values.append({
                'name': line.job_code,
                'project_id': project.id,
                'partner_id': order.partner_id.id,
                'artwork_sale_order_id': order.id,
                'artwork_sale_order_line_id': line.id,
            })
        self.env['project.task'].create(task_values)

        return {
            'type': 'ir.actions.act_window',
            'name': _('Artwork Project'),
            'res_model': 'project.project',
            'view_mode': 'form',
            'res_id': project.id,
            'target': 'current',
        }
