from . import product_specification
from . import requirement_form
from . import crm_lead
from . import product_extension
from . import customer_rating
from . import res_partner
from . import sale_order
from . import job_code_configuration
from . import stock_lot
from . import purchase_order

from . import job_production_process
from . import documents_sales_sync
