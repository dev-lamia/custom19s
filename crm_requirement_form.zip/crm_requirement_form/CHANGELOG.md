# Changelog — CRM Requirement Form (Odoo 19)

> This file is maintained with the module. Dates are ISO 8601. Feature implementation dates are **not inferred** from documentation dates or ZIP/file timestamps.

## [Unreleased] — Documentation Updated: 2026-11-04

### [Changed] — Customer-specific Requirement Form dropdown in Sale Orders (2026-11-04)
- [2026-11-04] Filtered **Sales → Quotation / Sale Order → Requirement Form (Optional)** by the currently selected Customer using `domain="[('partner_id', '=', partner_id), ('partner_id', '!=', False)]"` on `sale.order.requirement_form_id` (`views/sale_order_views.xml`). Only existing Requirement Forms for that exact Customer are selectable in the UI; an empty Customer yields no results.
- [2026-11-04] Preserved existing optional selection, no-create settings, New/Repeat Job flags, existing onchanges, Job Code/GDN processing, and all server-side validations. This is a UI dropdown restriction only, not a new backend constraint or automatic clearing of a previously selected Requirement Form.

### [Docs] — Sale Order customer filtering (2026-11-04)
- [2026-11-04] Updated `README.md` with domain, field paths, limitations, and proposed tests SO-CF-01–05. Updated this changelog without changing the module manifest or version. Static source-level checks only; live Odoo upgrade not verified.


### [Fixed] — Job Code Sale Orders smart button visibility (2026-11-04)
- [2026-11-04] Moved the existing **Sale Orders** smart button into a high-priority inherited view (`sale_job_code_configuration_sale_orders_smart_button_view`), so the button is injected into the final Job Code smart-button box alongside buttons from other modules (such as Plate TDS). GDN form button and the Job Code form's field layout are unchanged.
- [2026-11-04] Reused existing `sale_order_count` and `action_view_sale_orders()` for unique SO count and navigation, including New and Repeat Sale Orders. No Python model, generation, business validation, or Sale Order mapping was changed.
- [2026-11-04] Updated documentation. Static XML/view-inheritance and ZIP checks completed; live Odoo validation not performed.


### [Added] — Job Code Sale Orders smart button and latest SO field (2026-11-04)
- [2026-11-04] Added a Job Code form **Sale Orders** smart button that counts and opens unique SOs containing matching `sale.order.line.job_code` values, including Repeat Jobs and historical SO states; no new sales records are created (`models/job_code_configuration.py`, `views/gdn_configuration_views.xml`).
- [2026-11-04] Display the latest confirmed SO using this code in **Source & Traceability → Sale Order** using non-stored `latest_sale_order_id`. The SQL-view's original stored `order_id` column and all Job Code source fields remain unchanged.
- [2026-11-04] Display clickable **GDN Number** through non-stored `gdn_link_id`, with a text-number fallback for historical lines whose `gdn_configuration_id` is empty; no GDN or SO lines are modified.

### [Changed] — Clickable GDN Job Code references (2026-11-04)
- [2026-11-04] Changed the GDN **Job Code** display from plain, comma-separated text to safe HTML links for every distinct Job Code using the GDN (`related_job_code_links`). Each link opens the existing SQL-view-backed Job Code Configuration; the previous `related_job_codes` Char computation remains available (`models/sale_order.py`, `views/gdn_configuration_views.xml`).

### [Docs] — Job Code / GDN navigation and regression checks (2026-11-04)
- [2026-11-04] Updated `README.md` and `CHANGELOG.md` with current field mappings, newest-confirmed SO rules, repeat-history lookup, legacy GDN fallback and proposed QA JC-GDN-01–09. Implementation and documentation updated on this date; no claim of live Odoo validation.


### [Changed] — GDN Sale Orders smart button and Job Code field (2026-11-04)
- [2026-11-04] Replaced the **Job Codes** smart button on `sale.gdn.configuration` with a **Sale Orders** smart button that counts distinct `sale.order` records containing GDN-linked lines; clicking opens a single matching order or a filtered list of all matching orders. The lookup covers `gdn_configuration_id` and legacy records with only a `gdn_number` on the line (`models/sale_order.py`, `views/gdn_configuration_views.xml`).
- [2026-11-04] Added a read-only **Job Code** field under **Source & Traceability** showing distinct nonempty Job Codes from those linked order lines. When multiple Job Codes use the same GDN, all are displayed as comma-separated codes; the original Source Sale Order field remains unchanged.
- [2026-11-04] Kept `job_code_ids`, `job_code_count`, and `action_view_job_codes` in the model for compatibility, but removed only their form smart-button presentation. No Job Code serial generation, GDN numbering, SO confirmation, filtering by status, business validations, or record ownership behavior is changed.

### [Docs] — GDN Sale Order traceability (2026-11-04)
- [2026-11-04] Updated `README.md` workflow, technical model/field references, dynamic matching rules, upgrade instructions and proposed tests GDN-SO-01 through GDN-SO-06; updated this changelog. Only `models/sale_order.py`, `views/gdn_configuration_views.xml`, `README.md` and `CHANGELOG.md` were intentionally changed. Source-level checks only; Odoo runtime testing not performed.


### [Changed] — Customer-filtered Previous Req Form dropdown (2026-11-04)
- [2026-11-04] Limited the **Previous Req Form** Many2one dropdown to Requirement Forms with `partner_id` equal to the current form's selected **Customer** (`views/requirement_form_views.xml`, model `crm.requirement.form`). The dynamic domain is `[('partner_id', '=', partner_id), ('partner_id', '!=', False)]`. Multiple earlier REQs belonging to that customer remain selectable; no new state/domain restrictions were added.
- [2026-11-04] No Python, Job Code generation/reuse, GDN, requirement-copy, approval, or server-side validation logic was changed. The previously existing Repeat Job, self-selection, and specification-presence conditions are preserved.

### [Docs] — Customer-filtered source selection (2026-11-04)
- [2026-11-04] Updated `README.md` navigation, source-field mapping, explicit UI-only domain scope and proposed QA cases CF-01 through CF-05. `CHANGELOG.md` records the view-only functional modification and documentation update. Static XML and ZIP checks performed; live Odoo testing **not performed**.


### [Changed] — Sale Order shows only the selected Job Type (2026-11-04)
- [2026-11-04] In `views/sale_order_views.xml`, show the read-only **New Job** checkbox only when the linked Requirement Form marks New Job, or the read-only **Repeat Job** checkbox only when it marks Repeat Job. The unchecked checkbox is hidden; both are hidden if neither is selected or there is no linked Requirement Form. This changes only form visibility; no business logic, fields, Job Code generation, or source synchronization behavior is changed.
- [2026-11-04] Updated `README.md` and proposed QA case RJ-07 for single-selected-Job-Type display. XML parsing and ZIP consistency were checked; the updated form has not been tested on a live Odoo instance.

### [Fixed] — Repeat Job reuses the previous Job Code (2026-11-04)
- [2026-11-04] Corrected `sale.order._generate_missing_job_codes()` to skip Sale Orders linked to a **Repeat Job**; existing New Job and direct Sale Order confirmation-time generation, customer-wise serial continuity and five-digit padding are unchanged (`models/sale_order.py`).
- [2026-11-04] Added `sale.order._sync_repeat_job_codes_from_source()` before confirmation to reuse and verify the original design's Job Code. If the selected previous design has no generated code, confirmation raises `UserError` rather than creating a new serial.
- [2026-11-04] Added `crm.requirement.specification._get_repeat_job_source_line()` to resolve a design-specific historical coded Sale Order Line (preferring the selected GDN, with repeat-of-repeat source-chain fallback). On selecting **Previous Req Form**, the copied design's Job Code link now displays the previous code alongside the already-existing GDN link (`models/product_specification.py`).
- [2026-11-04] Updated `crm.requirement.form._prepare_sale_order_line_from_specification()` to populate the prior source `job_code` on Repeat Job quotation lines, retaining the existing GDN and other source mapping (`models/requirement_form.py`). Multiple designs retain independent source-code mapping.

### [Added] — Read-only Requirement Form Job Type in Sale Order (2026-11-04)
- [2026-11-04] Added non-stored, read-only related `sale.order.new_job` and `sale.order.repeat_job` fields, displayed directly under the optional Requirement Form selector in the Sale Order form only when a Requirement Form is selected (`models/sale_order.py`, `views/sale_order_views.xml`). These reflect the current New Job / Repeat Job choices made on the linked Requirement Form, without adding a second editable job-type source.

### [Docs] — Repeat Job mapping, validations and test guide (2026-11-04)
- [2026-11-04] Updated `README.md` with the source-to-repeat design mapping, conditional confirm flowchart, code reuse versus generation, Sale Order indicators, synchronization details, no-source-code error, upgrade requirements and proposed manual tests RJ-01 through RJ-08. Preserved historical notes, unchanged manifest version, and existing feature documentation.
- [2026-11-04] **Verification:** Source-level syntax/XML/archive checks performed; live Odoo server and user-interface behavior **not runtime-tested**. This release changes only `models/product_specification.py`, `models/requirement_form.py`, `models/sale_order.py`, `views/sale_order_views.xml`, `README.md` and `CHANGELOG.md`.


### [Fixed] — CRM Industry Category on Lead → Opportunity conversion (2026-10-27)
- [2026-10-27] Show the existing `crm.lead.industry_category_id` in the Opportunity-specific partner group (`views/crm_lead_views.xml`); previously it was only in the Lead-specific group and became hidden after conversion.
- [2026-10-27] Preserve the selected Lead Industry when conversion first links a Customer with no Industry, and pass it through the existing Customer sync; a Customer's already-set Industry still takes precedence (`models/crm_lead.py`). No new field or schema change.

### [Changed] — Job Code incremental segment five-digit padding (2026-10-27)
- [2026-10-27] Update `sale.order._generate_missing_job_codes()` to generate the fourth Job Code segment with `:05d` instead of `:04d` (`models/sale_order.py`). Example new code `1-01-00019-00003-00`.
- [2026-10-27] Historical serials remain readable for continuity; existing Job Codes are **not** rewritten. Prefixes, suffixes, generation trigger and all other sequences remain unchanged.

### [Docs] — Industry Category and Job Code serial format (2026-10-27)
- [2026-10-27] Updated `README.md` with field placement, conversion data handling, serial format examples, compatibility, upgrade guidance, and proposed manual QA; recorded both implementation changes in this `CHANGELOG.md`. Static checks only, no live Odoo runtime testing.


### [Fixed] — Job Code Disable popup displays Job Code numbers (2026-10-27)
- [2026-10-27] Corrected the **Selected Job Codes** display in **Sales → Configuration → Job Code Configurations → Actions → Disable**. The popup previously rendered `sale.order.line` display names; it now displays the selected lines' actual `job_code` references, comma-separated for multiple selections.
- [2026-10-27] Added computed, read-only `sale.job.code.disable.wizard.job_code_labels` from `job_line_ids.job_code` (`models/job_code_disable_wizard.py`); the wizard form shows that label while retaining hidden `job_line_ids` (`views/gdn_configuration_views.xml`). The existing reason requirement, archive-by-flag behavior and Chatter logging are unchanged. Implementation date is supported by the current project update; live Odoo runtime test pending.

### [Changed] — Job Code and GDN Chatter side-panel layout (2026-10-27)
- [2026-10-27] Corrected the desktop Chatter layout for both **Job Code Configurations** and **GDN Configurations** in `static/src/scss/requirement_form_backend.scss`. The rule now targets Odoo 19's `.o_form_renderer:has(.o_crm_req_config_hero)` ancestor directly, rather than a nested selector that did not affect the renderer.
- [2026-10-27] At viewport widths of at least **1100px**, the form sheet stays to the left and the native Chatter container is presented as a **370px right-side panel**. Smaller widths retain the default responsive layout. Native field tracking, messages, audit history, uploads and existing business logic were not changed. Browser/asset regeneration and live layout verification remain necessary.

### [Docs] — Job Code and Chatter documentation-only update (2026-10-27)
- [2026-10-27] Updated `README.md` with the selected Job Code label mapping, Disable popup workflow, side-panel SCSS selector, responsive behavior, deployment and proposed test cases. Updated this `CHANGELOG.md` with the verified implementation notes and today's documentation date.
- [2026-10-27] **This ZIP packaging pass modifies only `README.md` and `CHANGELOG.md`.** Python, XML, SCSS, manifest, security files and all other contents remain byte-identical to the supplied side-Chatter-corrected ZIP. No new runtime changes are introduced by this documentation-only edit.

### [Added] — Job Code Disable with mandatory reason (2026-10-26)
- [2026-10-26] Added Job Code Configurations list **Actions → Disable** wizard for single or multiple selected records; the reason is mandatory and is posted to each Job Code Chatter.
- [2026-10-26] Added dedicated `sale.order.line.job_code_disabled` storage and SQL-view read-only `active` projection, ensuring disabled Job Codes are hidden without disabling underlying Sale Orders, lines, GDNs or documents. Added a **Disabled** search filter.
- [2026-10-26] Added Job Code wizard/model import, ACL and list-bound server action. Existing GDN Disable, manual Job Code field save, tracking and document workflows are not modified. Static checks only; live Odoo validation is pending.


### [Fixed] — GDN Disable reason popup (2026-10-26)
- [2026-10-26] Fixed `sale.gdn.configuration.action_open_disable_wizard()` (`models/sale_order.py`) so Actions → Disable opens an unsaved `sale.gdn.disable.wizard` popup rather than creating it without the required `reason` field.
- [2026-10-26] Selected GDNs are supplied via the wizard action's `default_gdn_ids` context; confirming with a reason uses the existing archive and Chatter audit workflow. GDN documents and other business functionality remain unchanged.
- [2026-10-26] Source syntax and ZIP checks passed; live Odoo popup/archive behavior remains to be tested after upgrade.



### [Fixed] — Job Code manual Save and native Chatter tracking (2026-10-26)
- [2026-10-26] Fixed the SQL-view-backed Job Code `write()` flow for manual **Production Process**, **Pouch Details** (Side/Bottom Gusset), and **Quality Department** (GSM and Quality Documents) inputs (`models/job_code_configuration.py`). Input fields still persist in their existing Sale Order Line or Job Code repeat-size records; no new columns or changed SQL view definition.
- [2026-10-26] Forward Job Code-only Sale Order Line fields with the existing `skip_sale_line_linked_sync` context to prevent unrelated Requirement/GDN resynchronization when editing manual Job Code parameters. Update Job Code-specific repeat-size/measuring-unit values in their existing dedicated table, flush the actual storage models, and invalidate SQL-view caches before reading saved values.
- [2026-10-26] Replace early/precommit `mail.thread` tracking finalization with direct native Odoo `_message_track()` after source values are saved and refreshed. This generates structured `mail.message`/`mail.tracking.value` old/new entries, including process tags and Quality Documents, only for fields whose saved values actually changed; obeys `tracking_disable` and `mail_notrack` contexts. No historical edits are backfilled.
- [2026-10-26] Updated README verification steps. Python syntax, source-level checks and ZIP integrity validated; actual Odoo server/UI behavior must be checked after module Upgrade.


### [Added] — GDN Disable action with mandatory archive reason (2026-10-26)
- [2026-10-26] Added **Actions → Disable** for selected GDN Configuration list records. A modal requires a reason before archiving the selected GDNs (`views/gdn_configuration_views.xml`, new `sale.gdn.disable.wizard`). Cancel leaves the records unchanged; multiple selected records receive the same supplied reason.
- [2026-10-26] Added tracked `sale.gdn.configuration.active` (`default=True`), so Disable uses standard Odoo archive behavior (`active=False`) without deleting GDNs, documents or existing relational links. Posted the user-entered reason to each record's Chatter using `mail.mt_note` (`models/sale_order.py`, `models/gdn_disable_wizard.py`).
- [2026-10-26] Added a **Disabled** GDN search filter to retrieve archived records, imported the wizard model and granted Sales Users wizard access. No existing Job Code, Sale Order, document, or GDN business logic changed. Updated README with workflow, implementation and proposed QA. Static checks only; Odoo runtime not tested.


### [Fixed] — GDN and Job Code Chatter / manual-field tracking (2026-10-26)
- [2026-10-26] Made native Odoo Chatter visible below the wide GDN and Job Code form sheets and enabled reload flags in both forms. The previous `<chatter/>` declarations and GDN stored-field `tracking=True` flags remain.
- [2026-10-26] Updated SQL-view-backed Job Code tracking to finalize field-change messages after its existing source-line/repeat-size writes, including tracking for Job Code-only Quality Documents uploads. Native tracking retains previous/new values for modified Production Process, Pouch Details and Quality Department inputs.
- [2026-10-26] Added GDN form document-row change history showing Document Type and old/new uploaded file names. GDN's standard editable Print Type, No of Colors, Print Direction and design notes retain native field tracking. No document sync or business logic was changed.
- [2026-10-26] Updated README developer notes and deployment test guidance. Static syntax / archive checks performed; no live Odoo runtime testing and no historical edits retroactively logged.



### [Changed] — Rename Job Code document label (2026-10-20)
- [2026-10-20] In Job Code → Quality Department, renamed the visible **Job Code Documents** section heading and upload field/button label to **Quality Documents**. The technical field `job_quality_attachment_ids`, stored files, permissions, upload behavior, and Requirement Form/GDN isolation are unchanged; updated README to match.


### [Changed] — Job Code Quality Department: independent file uploads (2026-10-20)
- [2026-10-20] Replaced the Job Code **Design Documents** line list in **Quality Department** with a simple **Job Code Documents** multi-file upload field (`many2many_binary`). Removed Document Type dropdown, category rows and Add a line list from **Job Code only**.
- [2026-10-20] New Job Code files use a dedicated `sale.order.line.job_quality_attachment_ids` Many2many attachment relation, exposed as `sale.job.code.configuration.job_quality_attachment_ids` and saved via the existing SQL-view `write()` forwarding. Nothing is fetched from or sent to Requirement Form / Product Specification / GDN document lines.
- [2026-10-20] Disabled Job Code document link auto-population on Sale Order confirmation/line write and Requirement Design document create/write; removed its upgrade backfill from the manifest. Retained the legacy line model/table and migration source file without running the migration, to preserve historical data. Requirement Form ↔ GDN document behavior is unchanged.
- [2026-10-20] Updated README technical mapping, deployment notes and proposed tests. ZIP/XML/Python static checks only; Odoo runtime testing has not been performed.

### [Superseded] — Previous Job Code Document Type rows (2026-10-20)
- [2026-10-20] Job Code → Quality Department → Design Documents now uses its own `sale.job.code.document.line` row model, analogous to GDN's `sale.gdn.document.line`. `document_type_id` remains a Many2one to the existing `crm.requirement.document.type` master, with explicit empty domain `[]` on Job Code's inline list; active configured types are available without an empty `id in []` restriction.
- [2026-10-20] Added `models/job_code_document_line.py` and `sale.order.line.job_code_document_line_ids`. Job Code's SQL-view model uses a non-stored `job_document_line_ids` related One2many and routes write commands to its Sale Order Line. The new table stores only Sale Order Line ↔ source Product Specification document relationships; type names and uploaded attachments are live related fields on existing source document rows (no duplicate file storage).
- [2026-10-20] Added idempotent backfill for existing Job Codes (`data/job_code_document_migration.xml`), source-document creation hook and Sale Order confirmation linking. Existing Product Specification and GDN source-file synchronization is retained; duplicate-copy specifications remain read-only. Changed the manifest, ACL, model imports, Job Code view and relevant models; no changes to GDN document view, GSM/production fields or the Job Code SQL SELECT.
- [2026-10-20] Updated README technical field mapping, upgrade instructions and proposed manual checks. Python/XML/archive static verification only; Odoo runtime testing pending.


### [Changed] — GDN Documents: manual Add a line, no empty defaults (2026-10-20)
- [2026-10-20] Stopped automatic creation of six **empty** GDN Document Type rows on new GDNs or subsequent REQ→GDN sync (`models/sale_order.py`, `sale.gdn.configuration._sync_document_lines`). GDN Documents remains an inline **Add a line** table with the same configured Document Type dropdown and multi-file uploads; `views/gdn_configuration_views.xml` is unchanged.
- [2026-10-20] On module upgrade, `_bootstrap_existing_gdn_document_lines()` now prunes only the old empty, non-source-linked standard-category placeholders. Existing uploaded GDN files, Requirement Form-sourced files, legacy attachment fields and custom document rows remain intact and synchronized; categories with real legacy/source files are still created as needed.
- [2026-10-20] Preserved the six configured Document Type **master options** and their dropdown selection (they are no longer six mandatory blank GDN rows). Updated `README.md` with the precise distinction, upgrade behavior and proposed QA-23 through QA-26. Python syntax and archive integrity checked; live Odoo runtime not tested.


### [Superseded] — Previous linked Job Code Design Documents (2026-10-20)
- [2026-10-20] Added a **Design Documents** section immediately below the existing GSM inputs in **Sales → Configuration → Job Code Configurations → Quality Department** (`views/gdn_configuration_views.xml`). Mirrors the Product Specification document list, including Document Type, multi-file Documents, sequence and inline **Add a line** editing.
- [2026-10-20] Introduced non-stored, live-linked `sale.job.code.configuration.design_document_line_ids` pointing to `requirement_specification_id.design_document_line_ids` (`models/job_code_configuration.py`). The SQL-view-backed Job Code `write()` forwards document commands to the source Product Specification. Existing `crm.requirement.design.document.line` hooks keep REQ → GDN documents synchronized; no duplicate stored document records or Job Code SQL columns were introduced.
- [2026-10-20] Preserved read-only document behavior for duplicate-copy Product Specifications using `job_design_documents_readonly`. Hide the section for jobs without a linked Product Specification. No changes to GSM fields, existing production, pouch/roll, GDN, REQ, security, manifest, or document synchronization code.
- [2026-10-20] Updated `README.md` with exact mapping, view behavior, upgrade and proposed QA steps. Static source checks only; live Odoo runtime not tested.

### [Changed] — GDN Source Sale Order Line form visibility (2026-10-19)
- [2026-10-19] Removed **Source Sale Order Line** (`source_line_id`) from the **GDN Configuration → Source & Traceability** form (`views/gdn_configuration_views.xml`, record `sale_gdn_configuration_form_view`). The GDN model field, optional list-view column, stored links, data synchronization and other form fields are preserved. This is a UI-only change; upgrade the module to apply the view update.
- [2026-10-19] Updated `README.md` with the GDN form visibility rule, deployment guidance and proposed QA-22. No Python/JS/SQL/security changes or live runtime test were made.

### [Added] — Job Code Bag/Pouch Details (2026-10-19)
- [2026-10-19] Added a **Pouch Details** tab (`job_pouch_details_tab`) in **Sales → Configuration → Job Code Configurations**, shown only when `fg_type == 'bag'`; Roll jobs retain the existing Roll Details layout. `views/gdn_configuration_views.xml` shows four fields: **Bag Length (mm)**, **Bag Width (mm)**, **Side Gusset (mm)** and **Bottom Gusset (mm)**.
- [2026-10-19] **Bag Length/Width** reuse existing read-only `sale.job.code.configuration.length` / `.width` SQL fields sourced from `sale.order.line.req_length` and `.req_width`; no duplicate length/width storage was introduced.
- [2026-10-19] Added editable `sale.order.line.job_pouch_side_gusset` and `job_pouch_bottom_gusset` (`fields.Float`, `copy=False`) in `models/sale_order.py`. Added corresponding SQL-view fields/SELECT aliases and permitted `write()` forwarding to `source_line_id` in `models/job_code_configuration.py`. These values are manual Sale Order Line data, not the pre-existing GDN `gusset` field. Module **upgrade** is required to create the underlying columns and rebuild the SQL view.

### [Changed] — Job Code Product Summary and GDN tab label (2026-10-19)
- [2026-10-19] Removed the redundant **Sale Product** (`product_id`) row **only from the Job Code Product Summary form**. Existing **Product** (`bag_type_product_tmpl_id`), Job Code SQL field, list view and other summary fields are preserved.
- [2026-10-19] Renamed the GDN form tab and its section heading from **Quantity & Dimensions** to **Dimensions** in `views/gdn_configuration_views.xml`. The page name `gdn_quantity_dimensions_tab`, underlying fields, Bag/Roll conditional visibility, and existing business rules are unchanged.

### [Docs] — Pouch Details and GDN Dimensions (2026-10-19)
- [2026-10-19] Expanded `README.md` with updated feature inventory, visibility/write restrictions, exact field-to-source mapping, SQL-view persistence, Product Summary cleanup, GDN label rename, synchronization notes, deployment steps and proposed QA-15 through QA-21.
- [2026-10-19] Updated `CHANGELOG.md` to record these changes with verified file/model references. **This documentation packaging pass changes only `README.md` and `CHANGELOG.md`; the existing functional patch is retained unchanged.** Source review and static archive checks only; live Odoo installation/upgrade not tested.

### [Changed] — GDN form Quantity & Dimensions display (2026-10-19)
- [2026-10-19] Removed only **Quantity** (`quantity`) and **Quantity UOM** (`quantity_uom_id`) from the GDN form's Quantity & Dimensions tab (`views/gdn_configuration_views.xml`); retained the underlying fields, GDN list columns, Total Thickness, Bag/Roll dimensions and all existing behavior.
- [2026-10-19] Updated `README.md` and `CHANGELOG.md` to reflect this UI-only change. XML syntax and ZIP integrity checked; Odoo runtime testing not performed.


### [Added] — Job Code Measuring Unit dropdown (2026-10-19)
- [2026-10-19] Added optional **Measuring Unit** (`job_measuring_unit_id`, `Many2one('uom.uom')`) immediately above **Process Sequence** in Job Code → Production Process. Choices are the existing Inventory → Configuration → Units & Packagings records; no new UoM options or menus were created.
- [2026-10-19] Persisted job-specific selection in existing `sale.job.code.repeat.size` storage (`measuring_unit_id`), projected by the Job Code SQL view (`LEFT JOIN repeat_cfg`). Extended the existing `write()` forwarding without adding a column to `sale.order.line` or affecting existing One Repeat Size. Deploy and upgrade the module to create the storage column and rebuild the SQL view.
- [2026-10-19] Updated `README.md` and `CHANGELOG.md`, including proposed non-executed QA. Python/XML and ZIP checks passed; Odoo runtime was not tested.

### [Changed] — GDN Documents UI (2026-10-19)
- [2026-10-19] Removed only the instructional helper text above GDN Documents line view. Kept editable document rows, attachments, configuration options and REQ synchronization unchanged (`views/gdn_configuration_views.xml`).
- [2026-10-19] Updated `README.md` and `CHANGELOG.md`; no runtime Odoo test performed.

### [Added] — Job Code GDN Color Details and Print Type (2026-10-19)
- [2026-10-19] Added **Color Details** (`gdn_color_details`, Integer related to `gdn_configuration_id.no_of_colors`) and **Print Type** (`gdn_print_type_id`, Many2one related to `gdn_configuration_id.print_type_id`) to Job Code → Product Summary. Both fields are read-only, live and visible for both Roll and Bag/Pouch FG types; edits remain on the GDN.
- [2026-10-19] Both fields are explicitly non-stored (`store=False`) on the `sale.job.code.configuration` SQL-view model: no new SQL columns, migration or stored Sale Order Line fields. Changed only `models/job_code_configuration.py` and `views/gdn_configuration_views.xml` plus `README.md` / `CHANGELOG.md`; other functionality unchanged. Static checks performed; Odoo runtime validation pending.

### [Fixed] — ZIP file access permissions (2026-10-18)
- [2026-10-18] Corrected ZIP mode `0600` to `0644` on `models/requirement_document_type.py`, `data/requirement_document_type_data.xml`, `data/requirement_document_type_migration.xml`, `README.md` and `CHANGELOG.md`. Prevents module import failures when Odoo runs as a non-owner inside Docker and the ZIP is extracted with stored Unix permissions.
- [2026-10-18] Module Python, XML, JS, security, manifest, database structures and functional behavior unchanged; updated `README.md` and `CHANGELOG.md` for troubleshooting. Live Docker/Odoo server validation pending.


### [Added] — Job Code Roll Details tab (2026-10-18)
- [2026-10-18] Added **Roll Details** tab to **Sales → Configuration → Job Code Configurations**, shown only for `fg_type == 'roll'`. Displays nine existing, read-only roll values (Coil Width, Cutoff Length, Final Roll Direction, Final Roll Weight, Final Roll OD, Final Roll Meters, Core ID, Core Thickness and Core Type) sourced through the existing `sale.job.code.configuration` SQL view from the linked Sale Order Line.
- [2026-10-18] Only `views/gdn_configuration_views.xml`, `README.md` and `CHANGELOG.md` are updated; no model/schema changes, manual production-process changes or GDN Roll Details changes. Odoo runtime validation pending.


### [Updated] — Document Types configuration and inline editing (2026-10-18)
- [2026-10-18] Replaced **Create Design Documents** popup with an inline editable One2many document list in Requirement Form → Product Specifications. Removed embedded document popup form; GDN Documents also uses inline list editing. Multi-file `many2many_binary` uploads remain supported per row (Odoo server testing pending).
- [2026-10-18] Added **Requirement Configuration → Document Types** master list (`crm.requirement.document.type`) with six default types, manager edit access, and shared selection dropdowns in Requirement Form and GDN. Disabled quick-creating categories from the row dropdown; new types are maintained in Configuration.
- [2026-10-18] Retained existing document line text fields for compatibility with existing GDN synchronization, added `document_type_id` for each document line, and an idempotent upgrade backfill that associates historical types/custom labels with configured records without dropping attachments.
- [2026-10-18] Updated `README.md` and `CHANGELOG.md`; executable changes are limited to document line models/views, configuration data/menu, manifest load entries, and related ACL/imports. Odoo staging runtime not verified.



### [Changed] — GDN Documents and manual design entries (2026-10-18)
- [2026-10-18] Replaced the read-only, related GDN Documents list with GDN-owned editable `sale.gdn.document.line` rows, supporting **Add a line**, free-text Document Type and multiple attachments per row; preserves REQ-to-GDN document import and synchronization without letting GDN uploads modify the original REQ.
- [2026-10-18] Automatically create six default GDN document types: Raw File, Customer Approved File, Digital Print File, Production Layout, Plate Layout and Color Separation. The module-upgrade data function backfills existing GDNs and brings historical categorized/uncategorized attachments into the new rows without deleting their original relations.
- [2026-10-18] Removed the **Existing Categorized GDN Documents** block from the GDN form; original legacy fields are retained in the model to protect existing integrations and stored files.
- [2026-10-18] Removed **Print Type** and **No of Colors** only from the Requirement Form Product Specifications view. GDN Design Information now uses independent, manually editable stored fields, not related writes into `sale.order.line`. Historical GDN display values are migrated once when present; Print Type configuration menu and other specification fields are unchanged.
- [2026-10-18] Updated source document row hooks and GDN source-file tracking to preserve direct GDN attachments when Requirement Form documents change. Added the GDN document-line ACL, model and upgrade data entry. Updated `README.md` and `CHANGELOG.md`; Odoo runtime test **not** performed.

### [Added]
- [2026-10-18] Introduced **Design Documents line view** on each Requirement Form Product Specification, supporting a free-text Document Type plus multiple uploaded files per row (`crm.requirement.design.document.line`, new model and access entry). GDN Documents now displays the linked design's document rows as a read-only, live related list. Previous six category attachment fields and existing file data are preserved and shown when populated. The new design-line model, `README.md` and `CHANGELOG.md` are included in the ZIP; requires module upgrade, not yet runtime-tested.
- [2026-10-18] GDN Configuration → Design Information: introduced optional editable alphanumeric **Print Direction** field (`sale.gdn.configuration.print_direction`, `fields.Char`) in `models/sale_order.py` and `views/gdn_configuration_views.xml`. Saved directly per GDN; no Requirement Form/Sale Order synchronization added.
- [2026-10-18] Job Code Configuration → Production Process: **One Repeat Size** is now a numeric `fields.Float` shown immediately before **No of Repeats** (`views/gdn_configuration_views.xml`). It is stored separately in new model `sale.job.code.repeat.size` (`models/job_code_configuration.py`), visible through a SQL-view `LEFT JOIN`. Existing One Up Size and No of Ups are unchanged.

### [Fixed]
- [2026-10-18] Resolved `psycopg2.errors.UndefinedColumn: column sale_order_line.job_one_repeat_size does not exist` by removing the ORM field and SQL view dependency on that missing Sale Order Line column. Repeat size now persists in a separate Job Code storage table.

### [Documentation]
- [2026-10-18] Updated `README.md` and `CHANGELOG.md` with corrected One Repeat Size location, numeric type, independent storage, migration instructions and proposed tests. Static validation completed; Odoo runtime verification pending.

### [Changed]
- [2026-10-18] [Fix] Replaced per-field Bag/Roll `invisible` expressions with two conditional `<group>` wrappers in `views/gdn_configuration_views.xml`. GDN Bag-only dimensions now belong to a Bag-only group (`fg_type != 'bag'`), while Roll-only Coil Width and Cutoff Length belong to a Roll-only group (`fg_type != 'roll'`). Quantity, UOM, and Total Thickness remain shared; stored field data and other tabs are untouched. Requires module upgrade on staging; no runtime verification performed.
- [2026-10-18] In **GDN Configuration → Quantity & Dimensions**, hide Bag-only **Length (mm)**, **Width (mm)** and **Gusset (mm)** when FG Type is Roll (`fg_type == 'roll'`). These values remain visible for Bag; Coil Width and Cutoff Length stay visible only for Roll. This is an Odoo 19 XML view visibility-only change.
- [2026-10-18] In **GDN Configuration → Quantity & Dimensions**, display **Coil Width (mm)** and **Cutoff Length (mm)** only when `fg_type == 'roll'`; remove those two fields from **Roll Details** to avoid duplicates. The two numeric values still come from related fields on the source Sale Order Line (`source_line_id.req_coil_width_mm` and `source_line_id.req_cutoff_length_mm`).
- [2026-10-18] Updated `views/gdn_configuration_views.xml` for layout/visibility only, and updated `README.md` and `CHANGELOG.md`. No models, business logic, manifest, security, or other views changed.

### [Docs]
- [2026-10-18] Added `README.md` with verified module metadata, navigation, features, models, workflows, configuration, sync mapping, security, installation, troubleshooting, and proposed QA scenarios.
- [2026-10-18] Added `CHANGELOG.md` to distinguish documented current source, historical upgrade-note evidence, and documentation-only modifications.
- [2026-10-18] Documented the already-present confirmed Sale Order **Select GDN clickable link** behavior, along with REQ Print Type, Roll Details, and GDN layer thickness field mapping.

### Scope
- **Current update (2026-10-18):** Display existing nine Roll values in the Job Code form when FG Type is Roll; presentation only. Existing Job Code SQL mapping and GDN values remain unchanged.
- **Latest update (2026-10-18):** corrected the Job Code One Repeat Size storage/type and its position before No of Repeats; removed the Sale Order Line missing-column dependency; updated model, view, ACL and documentation. GDN Print Direction and the prior GDN visibility fixes are unchanged.
- **Earlier same-day update (2026-10-18):** conditional Bag/Roll visibility adjustments in `views/gdn_configuration_views.xml`; retained in the current ZIP.
- **Previous same-day update:** moved Coil Width and Cutoff Length to Quantity & Dimensions (retained in this ZIP).
- **Earlier documentation-only update on 2026-10-18:** added README/CHANGELOG with no executable changes at that time.

## [19.0.0.0] — Release Date: Not verified

This is the **actual version string** in the supplied `__manifest__.py` (not a claimed new release). Baseline source inventory, reviewed on 2026-10-18:

### Verified present in supplied ZIP
- CRM Lead, Contact and Requirement Form integration; internal/public Requirement Form routes and Product Specifications.
- Configurable FG Types, Print Types (Surface and Reverse), Print and Finish, Features, Process Sequence and product category types.
- Sales GDN Configuration, GDN sequence generation/reuse and source traceability.
- GDN **Design Information**, conditional **Roll Details**, documents, and Layer 1–10 numeric Thickness (Microns) fields.
- Requirement Specification ↔ Sale Order Line/GDN synchronization paths and stored GDN snapshot logic.
- Job Code generation from confirmed Sale Order lines and Job Code SQL view.
- Sale Order Line `Select GDN` field: dropdown on quotations and clickable GDN record link after confirmation via `gdn_link_many2one` widget.
- Customer Ranking, Raw Material purchase Item Codes and inventory Item Code history.

**Runtime status:** Not tested as part of this documentation update.

## Historical notes preserved from the original module

The ZIP includes earlier `UPGRADE_NOTE*.txt` and `WHATSAPP_*.txt` documents. **Date: Not verified** for all historical implementation changes below. They are historical evidence, not proof that each statement still represents the current implementation or the current manifest version.

| Evidence file | Version mentioned by note | Documented historical topic | Implementation date |
| --- | --- | --- | --- |
| `WHATSAPP_SCHEMA_FIX.txt` | 19.0.0.1 | WhatsApp pre-migration field bootstrap | Not verified |
| `WHATSAPP_SCHEMA_FIX_V2.txt` | 19.0.0.2 | Earlier registry-bootstrap scenario | Not verified |
| `WHATSAPP_STUDIO_FIX.txt` | 19.0.0.3 | Existing Odoo Studio WhatsApp field placement compatibility | Not verified |
| `UPGRADE_NOTE_ITEM_CODE.txt` | 19.0.0.33 | Earlier raw material Item Code flow | Not verified |
| `UPGRADE_NOTE_ITEM_CODE_FIX.txt` | 19.0.0.34 | Earlier supplier-prefix schema fix | Not verified |
| `UPGRADE_NOTE_ITEM_CODE_LINE.txt` | 19.0.0.35 | Earlier PO-line Item Code logic | Not verified |
| `UPGRADE_NOTE_ITEM_CODE_INVENTORY_CONFIG.txt` | 19.0.0.36 | Item Code history configuration | Not verified |
| `UPGRADE_NOTE_REQ_SUMMARY*.txt` | Not specified | Requirement summaries, cards and manual entry notes | Not verified |
| `UPGRADE_NOTE_FEASIBILITY_GDN_FIX.txt` | Not specified | Repeat-job GDN persistence and feasibility filter note | Not verified |
| `UPGRADE_NOTE_VAT_SYNC.txt` | Not specified | VAT, Short Name, quotation and Incoterm synchronization note | Not verified |
| `UPGRADE_NOTE_JOB_CODE_PROCESS_FIELDS.txt` | Not specified | Job Code production process fields | Not verified |

There are no verified historical release dates in these notes. If confirmed Git tags or release records are supplied later, attach their dates here without inventing a timeline.

## Update policy

For every future ZIP update:
1. Verify the actual `__manifest__.py` version without changing it solely for documentation.
2. Add/refresh both `README.md` and `CHANGELOG.md` in the **module root**, inside the ZIP.
3. Document **only implemented/verified** changes, exact file/model references, and any tests actually executed.
4. Mark missing implementation/release dates as **Not verified**.
5. Preserve all unrelated code and archive entries.
