from odoo import api, fields, models, _


class ResUsers(models.Model):
    _inherit = "res.users"

    sale_customer_tag_ids = fields.Many2many(
        comodel_name="res.partner.category",
        relation="res_users_sale_customer_tag_rel",
        column1="user_id",
        column2="category_id",
        string="Customer Tags",
        help=(
            "When tags are selected, the Customer field on Sale Orders only "
            "shows customers having at least one of these tags. Leave empty "
            "to allow all customers."
        ),
    )

    @api.model
    def _get_sale_customer_tags(self):
        return self.env.user.sale_customer_tag_ids
