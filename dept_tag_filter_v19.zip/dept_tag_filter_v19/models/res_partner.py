from odoo import api, models


class ResPartner(models.Model):
    _inherit = "res.partner"

    @api.model
    def name_search(
        self,
        name="",
        domain=None,
        operator="ilike",
        limit=100,
    ):
        """Restrict Sale Order customer suggestions by the current user's tags.

        Odoo 19 renamed the second ``name_search`` argument from ``args`` to
        ``domain``.  Using the old keyword causes a TypeError during the OWL
        autocomplete RPC.
        """
        search_domain = list(domain or [])

        if self.env.context.get("filter_sale_customer_by_user_tags"):
            tag_ids = self.env.user.sale_customer_tag_ids.ids
            if tag_ids:
                search_domain.append(("category_id", "in", tag_ids))

        return super().name_search(
            name=name,
            domain=search_domain,
            operator=operator,
            limit=limit,
        )
